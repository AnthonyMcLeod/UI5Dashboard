sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.demo.controller.Main", {
		onInit: function() {
		},
		_mapResults: function(response) {
			var oModel = this.getView().getModel();
			oModel.setProperty("/items", response.d.results);
		},
		_loadIoT: function() {
			var oView = this.getView();
			var tableName = sap.ui.getCore().byId("tableId").getValue();

			var sUrl = "/iotmms/com.sap.iotservices.mms/v1/api/http/app.svc/" + tableName + "?$orderby=G_CREATED desc&$top=30&$format=json";
			oView.setBusy(true);
			var self = this;

			$.get(sUrl).done(function(results) {
					oView.setBusy(false);
					self._mapResults(results);
				})
				.fail(function(err) {
					oView.setBusy(false);
					if (err !== undefined) {
						var oErrorResponse = $.parseJSON(err.responseText);
						sap.m.MessageToast(oErrorResponse.message, {
							duration: 6000
						});
					} else {
						sap.m.MessageToast.show("Unknown error!");
					}
				});
		},
		_eventHandler: function(buttonType) {
			var self = this;
			var frequency;
			switch (buttonType) {
				case "start":
					if (sap.ui.getCore().byId("dropdownId").getSelectedItemId() === "justOnceId") {
						// Call _loadIoT() only once
						self._loadIoT();
					} else {
						// Determine the frequency
						switch (sap.ui.getCore().byId("dropdownId").getSelectedItemId()) {
							case "twoId":
								frequency = 2000;
								break;
							case "fiveId":
								frequency = 5000;
								break;
							case "tenId":
								frequency = 10000;
								break;
						}
						sap.ui.getCore().byId("startButtonId").setProperty("enabled", false);
						sap.ui.getCore().byId("stopButtonId").setProperty("enabled", true);
						sap.ui.getCore().byId("tableId").setProperty("editable", false);
						self.intervalId = setInterval(function() {
							self._loadIoT();
						}, frequency);
					}
					break;
				case "stop":
					// stop the interval
					clearInterval(self.intervalId);
					sap.ui.getCore().byId("startButtonId").setProperty("enabled", true);
					sap.ui.getCore().byId("stopButtonId").setProperty("enabled", false);
					sap.ui.getCore().byId("tableId").setProperty("editable", true);
					break;
			}
		}
	});

});